package codePkg;

public class StringReturner {
	// TODO: This function must *return* the parameter, someStr,
	//   which is a value of *type* String.
	public void returnThisString(String someStr) {
		
	}
}
