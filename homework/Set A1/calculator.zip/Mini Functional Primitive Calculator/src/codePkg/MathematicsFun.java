package codePkg;

public class MathematicsFun {

	//TODO: Return the total sum of the two numbers. (This function is done for you as an example.)
	public int addTwoNumbers(int n1, int n2) {
		// The total value is n1 + n2. You return that total value.
		return n1 + n2;
	}

	//TODO: Return the remaining value of the two numbers, assuming you are subtracting from n2.
	public int subtractTwoNumbers(int n1, int n2) {
		
	}

	//TODO: Return the product of the two numbers.
	public int multiplyTwoNumbers(int n1, int n2) {
		
	}
	
	//TODO: Return the quotient of the two numbers, assuming your n1 is the denominator.
	public int divideTwoNumbers(int n1, int n2) {
		
	}
	
	//TODO: Return the total sum of the three numbers.
	public int addThreeNumbers(int n1, int n2, int n3) {
		
	}
	
	//TODO: Suppose you want to return the value of this expression: (n1 + n2 + n3) * (n3 / n4 * (n1 - n3))
	// Return the value you obtain from this mathematical expression after calculation.
	// HINT TO GET FULL MARKS: Could you possibly re-use recycled material somewhere...?
	public int calculateExpression(int n1, int n2, int n3, int n4) {
		
	}
	
}
