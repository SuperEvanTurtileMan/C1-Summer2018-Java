package codePkg;

public class HotPotato {
	//TODO: Create some global variables that keeps track of the following:
	//           - has the hot potato been passed around yet? Please set it to false first.
	//             This global variable is called "hotPotatoHasBeenPassed".
	//           - the name of the user who has the hot potato. This global variable is called
	//			   "userName".

	
	//TODO: Create a function called "passTo" that takes in only *one parameter* of type String,
	//  called "name".
	//
	//  This parameter is the name of the user. If the string that was passed in
	//  was a name, then set the hotPotatoHasBeenPassed to true.
	//  If the strings "dropped" or "put on table" has been passed as the name of the user,
	//  then set the hotPotatoHasBeenPassed to false, and set the userName global var
	//  to be an empty String in the end, i.e. "".
}